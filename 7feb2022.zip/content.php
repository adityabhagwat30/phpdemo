<section class="container content-container">
<h1 class="main-heading">PHP Include <span>EXAMPLE</span></h1>
<div class="card-box">
   <div class="card">
      <p>Card</p>
      <h1>01</h1>
   </div>
   <div class="card">
      <p>Card</p>
      <h1>02</h1>
   </div>
   <div class="card">
      <p>Card</p>
      <h1>03</h1>
   </div>
   </div>
</section>