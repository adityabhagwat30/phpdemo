<footer>
   <div class="container">
   <p>It's footer here...</p>
   </div>
</footer>