<nav>
   <div class="container">
   <div class="logo">LOGO</div>
   <ul class="nav-links">
      <li><a href="#">Home</a></li>
      <li><a href="#">Services</a></li>
      <li><a href="#">Products</a></li>
      <li><a href="#">About us</a></li>
      <li><a href="#">Contact us</a></li>
   </ul>
   </div>
</nav>